# SAE15 Compte Rendu
## Siméon Poisson / Sacha Dzerahovic-Bonnetaud

# 1ere Partie: Pokefiche

## Choix que nous avons fait:

### Fonction `download_poke` :

Dans `pokefiche.py`, cette fonction prend le numéro d'id d'un Pokemoon et compil les statistiques utiles de ce Pokemoon dans un dictionnaire. Ces statistiques utiles comprennent:

- l'ID du Pokemoon
- Le Nom du Pokemoon
- La Taille du Pokemoon (En Décimètres)
- Le Poids du Pokemoon (En Hectogramme)
- L'url de l'image du sprite
- Le Type (Electrik, Eau, Terre,...)  
- les statistiques de combats (PV, Attaque, Défense, Attaque Spéciale, Défense Spéciale)
- La Vitesse (unitée non définie)

Le tout traduit en Français à l'aide de l'API

### Fonction `poke_to_md`

Dans `pokefiche.py`, cette fonction récupère le dictionnaire de la fonction `download_poke` ainsi que le nom du fichier à générer, et génère donc un fichier Markdown affichant de manière structurée les statistiques de ce dictionnaire.

On a dans l'ordre:

- Un titre "Fiche du Pokemon (nom du Pokemon)
- L'image du sprite de ce Pokemoon
- Un paragraphe décrivant le Pokemon avec toutes ses stats utiles affichées en gras (l'utilisation de `f` dans `(f'texte{dist})` permet d'inclure la valeur d'une variable ou d'un dictionnaire au sein d'une chaine de caractère `str`)  
Aussi les parties textuelles contiennent du code HTML, lisible par la format Markdown, pour l'affichage en gras par exemple.
- Une liste récapitulative de chaque stats, afin de rendre l'information claire.
  
Note:  
La taille et le poids, affichés dans l'API en Décimètre et en Hectogramme sont converties en Mètre et en Kilogramme pour une meilleur lisibilitée:

`taille_en_metre = int(dict['taille'])/ 10`  
`poids_en_kilo = int(dict['poids'])/10`

### Fonction `convert`:

Cette fonction (présente dans un fichier à part nommé `md_to_html.py`) prend l'emplacement d'un fichier Markdown existant, ainsi que le nom du fichier HTML à générer, puis convertit simplement le fichier Markdown en fichier HTML.

En plus de copier les données du fichier Markdown dans le fichier HTML, cette fonction vient rajouter les éléments de syntaxes nécessaire au fonctionnement d'un fichier HTML, au niveau du Header (Doctype, lang, meta charset, ...) ainsi que les balises HTML pour structurer la page.

### Fonction `fiche_pokemon`:

Dans `pokefiche.py`, cette fonction utilise les deux fonctions précédentes (`poke_to_md` et `download_poke`) ainsi que la fonction `convert` présente dans le fichier `md_to_html.py` pour prendre le numéro d'ID d'un Pokemon et générer un fichier Markdown et un Fichier HTML affichant les statistiques du Pokemon en question.

Note:  
Pour accéder à la fonction `convert` qui n'est pas présente dans le fichier `pokefiche.py`, on utilise la ligne `form md_to_html import convert` pour importer une fonction depuis un autre fichier.

### Utiliser la fonction directement depuis un terminal

Jusqu'à présent, nous ne pouvions éxécuter nos fonctions que "manuellement" depuis un éditeur. En exécutant le programme .py seul, rien ne se passe.  

Pour ce faire, nous utilisons une condition  
`if __name__ == "__main__":`  
qui, si le fichier est exécuté directement (sans éditeur) et que la ligne de commande exécutée pour lancer le script (comme `python pokefiche.py`) est suivi d'une ou plusieurs autres valeurs (exemple: `python pokefiche.py 25`), alors le script utilisera cette nouvelle valeur (`25`) dans notre fonction `fiche_pokemon`, (donc `fiche_pokemon(25)`) ce qui génèrera les fichiers voulu, comme expliqué précédemment.

## Difficultés rencontrés:

- Comprendre la manière d'accéder aux versions traduites en Français des valeurs, par l'utilisation des discitionnaires, les valeurs étant dans plusieurs sous parties de l'api. Difficultée surmontée grâce à un jeu de variables permettant de naviguer dans ces sous-parties.

- Les caractères accentués (é, è, ê, etc...) ne s'affichaient pas correctement sur la page HTML. Résolu en ajoutant la valeur `encoding="utf-8"` dans les lignes `with open`.

- Permettre l'utilisation de `python3 pokefiche.py 25`. Après de longues recherches, nous avons réussis à comprendre et utiliser les lignes `if __name__ == "__main__":` .

### Ce que nous avons appris durant cette partie du projet:

Nous avons appris à traiter les données d'une API en Python, compris le fonctionnement d'une API et l'intérêt de cette dernière.  
De plus, cela nous as permis de mieux maitriser l'utilisation des dictionnaires, de l'écriture et lecture dans de fichiers, du fonctionnement de la conversion MD HTML ainsi que des moyens pratiques comme l'importation de fonction depuis un autre fichier, ainsi que l'exécution d'un programme python directment depuis le terminal.

# 2nd Partie: Pokestats:

L'objectif est simple:  
Récupérer les statistiques de tout les Pokemon dont le nom contient une suite de lettre précise (définit par l'utilisateur) puis utiliser ces statistiques pour savoir quel Pokemon remporterait les Jeux Pokelympiques, dans les catégories suivantes:
- Course (vitesse)
- Soulevé de terre (poids + attaque)
- Décrocher le totem (le plus grand gagne)
- PokMMA (Attaque + Défense)

## Ou en est le projet à l'heure actuelle?

La seconde partie du projet n'a pas pû être finalisée. Toutefois, nous pouvons relever quelques avancements sur ce dernier:

### Fonction `get_dataset`

La seule fonction de cette seconde partie, qui permet quelques réalisations:

-Prendre le nombre de Pokemon à traiter (une valeur haute signifie un temps de chargement plus long)

-Pour chaque Pokemon, vérifier si le nom de ce dernier contient la suite de caractères proposé par l'utilisateur en amont. Si c'est bien le cas, les données du Pokemon (obtenue grâce à la fonction `download_poke` de la partie 1) sont enregistrées dans un dictionnaire.

C'est tout ce que le programme propose à l'heure actuelle. Cependant, il contient deux autres fonctionnalités, hors sujet et non finalisé que voici:

- Une barre de chargement, qui indique l'état d'avancement du chargement des données depuis l'API. Cette dernière s'adapte à la taille de la fenêtre utilisateur.

- Une tentative de cache. Malheuresement, nous n'avons pas réussi à mettre en place un cache pour accélérer la descente des données, ce fut la pricipale difficultée rencontrée durant cette seconde partie.

### Ce que nous avons appris:

Cette seconde partie nous as permi de manipuler l'API selon notre guise, et de réfléchir sur l'utilisation d'un cache (bien que non finalisé, nous avons compris le concept de base derrière le fonctionnement de cette outil.)

