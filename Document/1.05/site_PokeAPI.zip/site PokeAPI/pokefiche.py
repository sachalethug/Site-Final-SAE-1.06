import requests
from md_to_html import convert
import sys

def download_poke(numéro=int)->dict:

    #Prendre les valeurs disponible dans l'API pokeapi en fonction du numéro de Pokemon souhaité et enregistrer ses dernières dans un dictionnaire

    poke_dict = {}

    url_api = f"https://pokeapi.co/api/v2/pokemon/{numéro}"

    get_url_api = requests.get(url_api)

    donnee_json = get_url_api.json()

    #prise de certaines stat du Pokemon (données numériques donc pas de traduction possible)

    poke_dict["id"] = donnee_json['id']

    poke_dict["nom"] = f"{donnee_json['name']}"

    poke_dict["taille"] = f"{donnee_json['height']}"

    poke_dict["poids"] = f"{donnee_json['weight']}"


    for forms in donnee_json['forms']:

        #prise de l'URL correspondant au sprite du Pokemon

        forms_url = (f"{forms['url']}")

        get_forms_url_api = requests.get(forms_url)

        forms_json = get_forms_url_api.json()

        sprite_url = forms_json['sprites'].get('front_default')

        poke_dict["sprite"] = sprite_url


    for type in donnee_json['types']:

        #prise du type de Pokemon en version Française

        type_type = type['type']

        type_url = f"{type_type['url']}"

        get_type_url_api = requests.get(type_url)

        type_json = get_type_url_api.json()

        types_names = type_json['names']

        for names_dict in types_names :

            if names_dict['language']['name'] == "fr" :

                poke_dict["type"] = names_dict['name']


    for stat in donnee_json['stats']:

        #prise des statistiques du Pokemon en version Franaçise

        stat_stat = stat['stat']

        url_nom_stat = stat_stat['url']

        get_stat_url_api = requests.get(url_nom_stat)

        stat_json = get_stat_url_api.json()

        stat_names = stat_json['names']

        for names_dict in stat_names :

            if names_dict['language']['name'] == "fr" :

                nom_stat = names_dict['name']


        valeur_stat = stat['base_stat']

        poke_dict[nom_stat] = valeur_stat

    return(poke_dict)


def poke_to_md(dict: dict[str, str], fichier: str):
    # Création du fichier MarkDown
    with open(fichier, "w") as f:

        f.write(f'# Fiche du Pokemon <br> <span style="text-transform: uppercase;"> {dict['nom']} </span> \n\n')

        #Affichage du sprite, avec la balise html img

        f.write(f'<img src="{dict['sprite']}" width="200" height="200">\n\n')

        #Changement des valeurs taile et poids en Mètres et en Kilos.

        taille_en_metre = int(dict['taille'])/ 10
        poids_en_kilo = int(dict['poids'])/10

        #Ecrire les phrases dans la première partie du Markdown

        f.write(f'Ce dernier mesure **{taille_en_metre} m** pour **{poids_en_kilo} kg**\n\n')

        f.write(f'Il est de type **{dict['type']}** et a **{dict['PV']} points de vie**\n\n')

        f.write(f'Sa vitesse est de **{dict['Vitesse']}**\n\n')

        f.write(f"Il a **{dict['Attaque']} points d'attaque** et **{dict['Défense']} points de défense**\n\n")

        f.write(f"Enfin son **attaque spécial** vaut **{dict['Attaque Spéciale']} points** et sa **défense spécial** vaut **{dict['Défense Spéciale']} points**\n\n")

        #Ecrire la liste des données (sauf le sprite) dans la seconde partie du markdown
       
        f.write(f"## Récapitulatif:\n\n")

        for clee, valeur in dict.items():

            if clee != "sprite":

              f.write(f"- **{clee}** : {valeur}\n")

           
    f.close()




def fiche_pokemon(numéro=int):
#Prendre l'ID d'un Pokemon, convertir les données en Markdown, puis générer un fichier HTML à partir du fichier Markdown obtenu
    poke_to_md(download_poke(numéro),"fiche_pokemon.md")

    convert("fiche_pokemon.md","fiche_pokemon.html")


#Permet d'exécuter la fonction fiche_pokemon directement depuis un terminal, en spécifiant l'ID après la commande (python pokefiche.py 25)

if __name__ == "__main__":

    if len(sys.argv) > 1:

      numero = int(sys.argv[1])

      fiche_pokemon(numero)