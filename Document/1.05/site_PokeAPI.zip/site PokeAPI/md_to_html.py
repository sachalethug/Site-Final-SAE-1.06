import markdown

def convert(nom_fichier_md = str , nom_fichier_html = str):
#Prend un fichier Markdown et génère une copie de ce fichier au format HTML
    
    with open(nom_fichier_md, 'r') as fichier_md:

        contenu_md = fichier_md.read()
    
    contenu_html =  markdown.markdown(contenu_md)


#Genère le fichier HTML en ajoutant les lignes servant à formater la page
    with open(nom_fichier_html, 'w', encoding="utf-8") as fichier_html:
         
        fichier_html.write('<!DOCTYPE html>\n<html lang="fr">\n\n<head>\n\t<meta charset="UTF-8">\n\t<meta name="viewport" content="width=device-width, initial-scale=1.0">\n\t<title>Stat Pokemon</title>\n</head>\n\n<body>\n')
        
        fichier_html.write(contenu_html)
        
        fichier_html.write('\n</body>\n</html>')
