from pokefiche import download_poke
import json
import os

def get_dataset(idmax = int):
    #Prend le nombre de Pokemon à traiter en entrée

    #Tentative de cache
    ''''
    with open("cache/cache_list.txt", "w", encoding="utf-8") as cache:
        cache.write("")
    with open("cache/cache.json","w", encoding="utf-8") as cache:
        cache.write("{}")    
    '''

    #Variables, comme suite qui demande à l'utilisateur la suite de caractère à utiliser
    suite = input("Donnez une suite de caractère, le programme traitera les Pokemons avec cette suite dans leur nom : ")
    n = 1
    pokemons_dict = {}
    chargement = int(0)
    load_incr = 0

    #Tant que n (n désignant l'ID du Pokemon) n'a pas atteint la valeur entrée dans la fonction, traiter les stat de chaque Pokemon dans l'ordre
    while n != idmax+1 :

        donnee_poke = download_poke(n)

        #Si il y a la suite de caractère dans le nom du Pokemon
        if suite in donnee_poke['nom'] :
            
            pokemons_dict[n] = donnee_poke

            #Tentative de cache
            ''''
            with open("cache/cache_list.txt", "a", encoding="utf-8") as cache:

                cache.write(f"{n} ")            

            with open("cache/cache.json","a", encoding="utf-8") as cache:

                json.dump(donnee_poke , cache , indent=4)    
            '''        

        #Variables pour la barre de chargement
        chargement = chargement + 100 / idmax #Pourcentage d'avancement
        chargement_int = round(chargement, 1) #Le pourcentage est affiché à une décimale après la virgule (3.6% par exemple)
        caractere_barre_1 = "#"
        caractere_barre_2 = "."
        load_incr = load_incr + 1
        largeur = (os.get_terminal_size().columns) - 45 #Largeur de la page, moins le nombre de caractères non dynamiques (le texte)


        if load_incr % 2 == 0:#(Si load_incr modulo 2 est égal à zéro) pour le petit logo de chargement, tout à droite, afin que ce dernier alterne si load_incr est paire ou impaire

            #(Ligne répétée 4 fois pour l'animation du logo de chargement à droite), le reste affiche le pourcentage, une barre qui indique l'état d'avancement (#), une autre qui indique ce qu'il reste à charger (.), le tout moins la largeur pour adapter la taille à la fenêtre
            print(f"Récupération des données: {chargement_int}%","[",caractere_barre_1*int(chargement * largeur /100),caractere_barre_2* (largeur - int(chargement * largeur /100)),"]"," — ", end='\r')
            print(f"Récupération des données: {chargement_int}%","[",caractere_barre_1*int(chargement * largeur /100),caractere_barre_2* (largeur - int(chargement * largeur /100)),"]","-  ", end='\r')
        else:
            print(f"Récupération des données: {chargement_int}%","[",caractere_barre_1*int(chargement * largeur /100),caractere_barre_2* (largeur - int(chargement * largeur /100)),"]"," — ", end='\r')
            print(f"Récupération des données: {chargement_int}%","[",caractere_barre_1*int(chargement * largeur /100),caractere_barre_2* (largeur - int(chargement * largeur /100)),"]","  -", end='\r')
            #Note: ci dessus, le \r permet de réécrire sur la même ligne, ainsi la barre de chargement n'est pas dupliquée


        n = n + 1 


    print(pokemons_dict)

#Ci-dessous du code qui aurait pû nous être utile une fois le cache terminé

    ''''
    while n != idmax :

        pokemon_dict = download_poke(n)

        pokemon_nom = pokemon_dict['nom']



        if suite in pokemon_nom:

            pokemon_taille = pokemon_dict['taille']
            pokemon_poids = pokemon_dict['poids']
            pokemon_vitesse = pokemon_dict['Vitesse']
            pokemon_pv = pokemon_dict['PV']
            pokemon_attaque = pokemon_dict['Attaque']
            pokemon_defense = pokemon_dict['Défense']

            taille_en_metre = int(pokemon_taille)/ 10
            poids_en_kilo = int(pokemon_poids)/10

            print(f"{pokemon_nom} : Taille: {taille_en_metre} m, Poids: {poids_en_kilo} kg, Vitesse: {pokemon_vitesse}, Résistance: {pokemon_pv}, Force d'attaque: {pokemon_attaque}, Efficacité défence: {pokemon_defense}")

        else:
            print("")

        n = n + 1
    
    '''''